package uz.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "JARVIS"
        title.textSize = 28f
        root.addView(title)

        status = TextView(this)
        status.textSize = 16f
        root.addView(status)

        addButton(root, "1. Mikrofon va telefon ruxsati") { requestPerms() }
        addButton(root, "2. Boshqa ilovalar ustida ko'rsatish") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        addButton(root, "3. Xabarlarga kirish (bildirishnomalar)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        addButton(root, "4. Qulaylik xizmati (Jarvis'ni yoqing)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(root, "5. Batareya cheklovini olib tashlash") {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }
        addButton(root, "▶ Jarvis'ni yoqish") { startJarvis() }
        addButton(root, "■ To'xtatish") {
            stopService(Intent(this, JarvisService::class.java))
            Toast.makeText(this, "To'xtatildi", Toast.LENGTH_SHORT).show()
        }

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun addButton(parent: LinearLayout, label: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        parent.addView(b)
    }

    private fun requestPerms() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add("android.permission.POST_NOTIFICATIONS")
        requestPermissions(perms.toTypedArray(), 1)
    }

    private fun startJarvis() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Avval 1-tugma: mikrofon ruxsati", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, JarvisService::class.java))
        Toast.makeText(this, "Jarvis yoqildi. \"Jarvis\" deng.", Toast.LENGTH_LONG).show()
    }

    private fun ok(b: Boolean) = if (b) "✓" else "✗"

    private fun updateStatus() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val call = checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
        val overlay = Settings.canDrawOverlays(this)
        val notif = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val acc = JarvisAccessibility.instance != null
        status.text = "Mikrofon: ${ok(mic)}\n" +
            "Qo'ng'iroq: ${ok(call)}\n" +
            "Boshqa ilovalar ustida: ${ok(overlay)}\n" +
            "Xabarlar: ${ok(notif)}\n" +
            "Qulaylik xizmati: ${ok(acc)}\n"
    }
}
