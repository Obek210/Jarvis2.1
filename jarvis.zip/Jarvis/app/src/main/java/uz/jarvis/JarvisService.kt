package uz.jarvis

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.telecom.TelecomManager
import android.telephony.PhoneStateListener
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import android.view.KeyEvent
import java.util.Calendar
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

class JarvisService : Service(), TextToSpeech.OnInitListener {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var audio: AudioManager

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsRussian = false

    private var running = false
    private var speaking = false
    private var currentUtterance = ""
    private var awaitingCommand = false
    private var awaitingUntil = 0L
    private var beepMuted = false
    private var ringerSaved = false
    private var phoneListener: PhoneStateListener? = null
    private var pendingHandler: ((List<String>) -> Unit)? = null
    private var pendingUntil = 0L

    private val listenRunnable = Runnable { startListening() }
    private val unmuteRunnable = Runnable { setBeepMute(false) }
    private val speakDone = Runnable { onSpeakDone() }

    private fun onSpeakDone() {
        handler.removeCallbacks(speakDone)
        speaking = false
        scheduleListen(150L)
    }

    private val months = listOf(
        "yanvar", "fevral", "mart", "aprel", "may", "iyun",
        "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"
    )
    private val days = listOf(
        "yakshanba", "dushanba", "seshanba", "chorshanba", "payshanba", "juma", "shanba"
    )

    private val numWords = mapOf(
        "bir" to 1, "ikki" to 2, "uch" to 3, "tort" to 4, "besh" to 5,
        "olti" to 6, "yetti" to 7, "sakkiz" to 8, "toqqiz" to 9, "tokkiz" to 9,
        "on" to 10, "yigirma" to 20, "ottiz" to 30, "qirq" to 40,
        "ellik" to 50, "oltmish" to 60
    )

    private val cyr = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e",
        'ё' to "yo", 'ж' to "j", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k",
        'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r",
        'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "x", 'ц' to "ts",
        'ч' to "ch", 'ш' to "sh", 'щ' to "sh", 'ъ' to "", 'ы' to "i", 'ь' to "",
        'э' to "e", 'ю' to "yu", 'я' to "ya", 'ў' to "o", 'қ' to "q", 'ғ' to "g",
        'ҳ' to "h"
    )

    private val latDigraphs = listOf(
        "sh" to "ш", "ch" to "ч", "yo" to "ё", "yu" to "ю", "ya" to "я", "ye" to "е",
        "ts" to "ц", "o'" to "о", "g'" to "г", "o’" to "о", "g’" to "г",
        "oʻ" to "о", "gʻ" to "г", "ng" to "нг"
    )

    private val latSingles = mapOf(
        'a' to "а", 'b' to "б", 'c' to "к", 'd' to "д", 'e' to "е", 'f' to "ф",
        'g' to "г", 'h' to "х", 'i' to "и", 'j' to "дж", 'k' to "к", 'l' to "л",
        'm' to "м", 'n' to "н", 'o' to "о", 'p' to "п", 'q' to "к", 'r' to "р",
        's' to "с", 't' to "т", 'u' to "у", 'v' to "в", 'w' to "в", 'x' to "х",
        'y' to "й", 'z' to "з", '\'' to "", '’' to "", 'ʻ' to ""
    )

    // Aytilgan so'z -> ilova nomida qidiriladigan so'zlar
    private val aliases = mapOf(
        "yutub" to listOf("youtube"),
        "yutyub" to listOf("youtube"),
        "vatsap" to listOf("whatsapp"),
        "watsap" to listOf("whatsapp"),
        "uotsap" to listOf("whatsapp"),
        "sozlama" to listOf("settings", "nastroyki", "sozlamalar"),
        "kamera" to listOf("camera", "kamera"),
        "galer" to listOf("gallery", "galereya"),
        "galir" to listOf("gallery", "galereya"),
        "xrom" to listOf("chrome"),
        "hrom" to listOf("chrome"),
        "brauzer" to listOf("chrome", "internet", "browser"),
        "kalkulyator" to listOf("calculator", "kalkulyator"),
        "kalkulator" to listOf("calculator", "kalkulyator"),
        "telefon" to listOf("phone", "telefon"),
        "kontakt" to listOf("contacts", "kontakty", "kontakt"),
        "soat" to listOf("clock", "chasy"),
        "musiqa" to listOf("music", "muzyka"),
        "xarita" to listOf("maps", "karty")
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        tts = TextToSpeech(this, this)
        registerPhoneListener()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        running = true
        scheduleListen(400L)
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        setBeepMute(false)
        restoreRinger()
        try {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            phoneListener?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
        } catch (e: Exception) {
        }
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis ishlayapti")
            .setContentText("\"Jarvis\" deb buyruq bering")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    // ---------- Qo'ng'iroq holati ----------

    private fun registerPhoneListener() {
        try {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            val l = object : PhoneStateListener() {
                override fun onCallStateChanged(state: Int, phoneNumber: String?) {
                    handler.post { onCallState(state) }
                }
            }
            tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
            phoneListener = l
        } catch (e: Exception) {
        }
    }

    private fun onCallState(state: Int) {
        if (state == TelephonyManager.CALL_STATE_RINGING) {
            val quiet = getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("quiet_ring", true)
            if (quiet && !ringerSaved) {
                try {
                    if (audio.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
                        audio.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                        ringerSaved = true
                    }
                } catch (e: Exception) {
                }
            }
            scheduleListen(100L)
        } else {
            restoreRinger()
            if (state == TelephonyManager.CALL_STATE_IDLE) {
                try {
                    audio.isSpeakerphoneOn = false
                } catch (e: Exception) {
                }
            }
        }
    }

    private fun restoreRinger() {
        if (!ringerSaved) return
        try {
            audio.ringerMode = AudioManager.RINGER_MODE_NORMAL
        } catch (e: Exception) {
        }
        ringerSaved = false
    }

    private fun speakerOnLater(delayMs: Long) {
        handler.postDelayed({
            try {
                audio.isSpeakerphoneOn = true
            } catch (e: Exception) {
            }
        }, delayMs)
    }

    // ---------- Signalni (ding) o'chirish ----------

    private fun setBeepMute(mute: Boolean) {
        try {
            handler.removeCallbacks(unmuteRunnable)
            if (mute) {
                if (beepMuted || speaking || audio.isMusicActive) return
                if (audio.isStreamMute(AudioManager.STREAM_MUSIC)) return
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                beepMuted = true
            } else if (beepMuted) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                beepMuted = false
            }
        } catch (e: Exception) {
            beepMuted = false
        }
    }

    private fun muteBriefly(ms: Long) {
        setBeepMute(true)
        if (beepMuted) handler.postDelayed(unmuteRunnable, ms)
    }

    // ---------- Gapirish (TTS) ----------

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        t.setSpeechRate(1.0f)
        t.setPitch(0.8f)
        var r = t.setLanguage(Locale("uz", "UZ"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = t.setLanguage(Locale("ru", "RU"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                t.setLanguage(Locale.getDefault())
            } else {
                ttsRussian = true
            }
        }
        applySavedVoice(t)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                handler.post { if (utteranceId == currentUtterance) speakDone.run() }
            }
            override fun onError(utteranceId: String?) {
                handler.post { if (utteranceId == currentUtterance) speakDone.run() }
            }
        })
        ttsReady = true
    }

    private fun latToCyr(s: String): String {
        val t = s.lowercase(Locale.ROOT)
        val sb = StringBuilder()
        var i = 0
        while (i < t.length) {
            var matched = false
            for ((lat, cy) in latDigraphs) {
                if (t.startsWith(lat, i)) {
                    sb.append(cy)
                    i += lat.length
                    matched = true
                    break
                }
            }
            if (matched) continue
            val c = t[i]
            sb.append(latSingles[c] ?: c.toString())
            i++
        }
        return sb.toString()
    }

    private fun speak(text: String) {
        val t = tts
        if (!ttsReady || t == null) return
        setBeepMute(false)
        speaking = true
        recognizer?.cancel()
        val out = (if (ttsRussian) latToCyr(text) else text).take(3500)
        currentUtterance = "j" + System.currentTimeMillis()
        handler.removeCallbacks(speakDone)
        // TTS javob bermay qolsa, eshitishni baribir davom ettirish uchun
        handler.postDelayed(speakDone, minOf(25000L, 3000L + out.length * 90L))
        val r = t.speak(out, TextToSpeech.QUEUE_FLUSH, Bundle(), currentUtterance)
        if (r != TextToSpeech.SUCCESS) {
            handler.removeCallbacks(speakDone)
            speaking = false
        }
    }

    // ---------- Eshitish ----------

    private fun scheduleListen(delay: Long) {
        handler.removeCallbacks(listenRunnable)
        handler.postDelayed(listenRunnable, delay)
    }

    private fun ensureRecognizer(): SpeechRecognizer? {
        recognizer?.let { return it }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return null
        val created = SpeechRecognizer.createSpeechRecognizer(this)
        created.setRecognitionListener(listener)
        recognizer = created
        return created
    }

    private fun resetRecognizer() {
        recognizer?.destroy()
        recognizer = null
    }

    private fun startListening() {
        if (!running) return
        if (speaking) {
            scheduleListen(300L)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        // Suhbat paytida mikrofon band, shuning uchun kutamiz
        val mode = audio.mode
        if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) {
            scheduleListen(1500L)
            return
        }
        val r = ensureRecognizer() ?: return
        muteBriefly(900L)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "uz-UZ")
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 8)
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            resetRecognizer()
            scheduleListen(500L)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onEndOfSpeech() {
            muteBriefly(900L)
        }

        override fun onError(error: Int) {
            muteBriefly(700L)
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stopSelf()
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> scheduleListen(100L)
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    resetRecognizer()
                    scheduleListen(1000L)
                }
                else -> {
                    resetRecognizer()
                    scheduleListen(800L)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            muteBriefly(700L)
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            handleHeard(list ?: emptyList())
        }
    }

    // ---------- Matnni tushunish ----------

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase(Locale.ROOT)) {
            when (ch) {
                '\'', '’', 'ʻ', 'ʼ', '`', '‘' -> {}
                else -> sb.append(cyr[ch] ?: ch.toString())
            }
        }
        return sb.toString()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun words(s: String): List<String> = s.split(" ").filter { it.isNotEmpty() }

    private fun hasPrefix(cmd: String, vararg prefixes: String): Boolean =
        words(cmd).any { w -> prefixes.any { p -> w.startsWith(p) } }

    private fun hasExact(cmd: String, vararg exact: String): Boolean =
        words(cmd).any { w -> w in exact }

    private fun distance(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
            }
        }
        return dp[a.length][b.length]
    }

    private fun isWake(w: String): Boolean {
        if (w.length < 4 || w.length > 9) return false
        if (w.contains("jarvis")) return true
        return distance(w.take(6), "jarvis") <= 1 || (w.length <= 7 && distance(w, "jarvis") <= 2)
    }

    /** "Jarvis" so'zidan keyingi matnni qaytaradi, so'z topilmasa null. */
    private fun afterWake(t: String): String? {
        val ws = words(t)
        for (i in ws.indices) {
            if (isWake(ws[i])) return ws.drop(i + 1).joinToString(" ")
            if (i + 1 < ws.size && isWake(ws[i] + ws[i + 1])) return ws.drop(i + 2).joinToString(" ")
        }
        return null
    }

    private fun handleHeard(heard: List<String>) {
        val alts = heard.map { normalize(it) }.filter { it.isNotEmpty() }
        if (alts.isEmpty()) {
            scheduleListen(100L)
            return
        }
        val now = SystemClock.elapsedRealtime()

        val ph = pendingHandler
        pendingHandler = null
        if (ph != null && now < pendingUntil) {
            ph(alts)
            scheduleListen(150L)
            return
        }

        if (awaitingCommand && now < awaitingUntil) {
            awaitingCommand = false
            runCommand(alts.map { afterWake(it) ?: it })
            scheduleListen(150L)
            return
        }
        awaitingCommand = false

        for (t in alts) {
            val rest = afterWake(t) ?: continue
            if (rest.isEmpty()) {
                awaitingCommand = true
                awaitingUntil = now + 12000L
                speak("Eshitaman")
            } else {
                val others = alts.mapNotNull { afterWake(it) }.filter { it.isNotEmpty() && it != rest }
                runCommand(listOf(rest) + others)
            }
            scheduleListen(150L)
            return
        }
        scheduleListen(100L)
    }

    private fun runCommand(cmds: List<String>) {
        for (c in cmds) {
            if (c.isEmpty()) continue
            val action = resolve(c) ?: continue
            action()
            return
        }
        val first = cmds.firstOrNull { it.isNotEmpty() }
        val key = getSharedPreferences("jarvis", MODE_PRIVATE).getString("api_key", "") ?: ""
        if (first != null && key.isNotEmpty() && words(first).size >= 2) {
            askAi(first, key)
        } else {
            speak("Tushunmadim")
        }
    }

    private fun resolve(cmd: String): (() -> Unit)? {
        val w = words(cmd)
        fun p(vararg x: String): Boolean = hasPrefix(cmd, *x)
        fun e(vararg x: String): Boolean = hasExact(cmd, *x)

        // qo'ng'iroq
        if (e("rad", "radd") ||
            (p("trubka") && e("qoy", "qoying", "tashla", "tashlang")) ||
            (p("qongiroq") && p("tugat", "bekor"))
        ) return { endCall() }
        if (p("javob", "trubka", "qabul", "kotar")) return { answerCall() }
        if ((p("qongiroq", "zvonok") && !p("tugat")) ||
            (p("telefon") && e("qil", "qiling", "qilib", "qilgin")) ||
            e("chaqir", "chaqiring")
        ) return { makeCall(cmd) }

        if (p("sms", "xabar", "habar") && e("yoz", "yozing", "yozib", "yubor", "yuboring", "jonat")) {
            return { composeSms(cmd) }
        }
        if (p("xabar", "habar", "sms", "yozishma")) return { readMessages() }

        // qurilma
        if (p("fonar", "chiroq", "flesh", "flash")) return { setTorch(!p("ochir", "yop", "uchir")) }
        if (p("ovoz", "tovush", "volume")) {
            if (p("almash", "ozgart", "boshqa")) return { nextVoice() }
            if (p("oshir", "baland", "kop", "kuchay", "katta")) return { changeVolume(true) }
            if (p("kamay", "past", "pasay", "kichik", "sekin")) return { changeVolume(false) }
            return null
        }
        if (p("toxtat", "pauza", "pause") || e("stop")) {
            return { mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE, "To'xtatdim") }
        }
        if (p("davom", "ijro", "play")) return { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY, "Davom ettiraman") }
        if (p("keyingi", "next")) return { mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT, "Keyingisi") }
        if (p("oldingi", "previous")) return { mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Oldingisi") }

        // ma'lumot
        if ((p("soat") && p("nech")) || p("vaqt")) return { sayTime() }
        if (p("sana", "bugun")) return { sayDate() }
        if (p("batareya", "zaryad", "quvvat")) return { sayBattery() }
        if (p("taymer", "timer")) return { setTimer(cmd) }
        if (p("budilnik", "uygotgich", "budilnig")) return { setAlarm(cmd) }
        if (p("kurs", "dollar", "yevro", "evro", "rubl")) return { sayRate(cmd) }
        if (p("havo", "obhavo", "pogoda", "harorat", "gradus")) return { sayWeather(cmd) }

        // tugmalar
        if (p("orqaga", "ortga")) return { nav(AccessibilityService.GLOBAL_ACTION_BACK, "Orqaga") }
        if (e("bosh") || p("uyga")) return { nav(AccessibilityService.GLOBAL_ACTION_HOME, "Bosh ekran") }
        if (p("oxirgi")) return { nav(AccessibilityService.GLOBAL_ACTION_RECENTS, "Oxirgi ilovalar") }
        if (p("qulf")) return { nav(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Qulflayman") }
        if (p("skrin", "screenshot") || (p("ekran") && p("rasm"))) {
            return { nav(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Skrinshot") }
        }
        if (p("bildirish", "shtorka")) {
            return { nav(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Bildirishnomalar") }
        }

        if (p("rasm", "surat", "selfi") && e("ol", "olgin", "oling", "olib")) return { takePhoto(cmd) }
        if (e("chal", "chalib", "chaling") ||
            (e("qoy", "qoyib", "qoying") &&
                p("qoshiq", "qoshig", "musiqa", "klip", "kuy", "youtube", "yutub", "yutyub"))
        ) return { playSong(cmd) }

        if (p("qidir", "izla", "search")) return { webSearch(cmd) }

        // ilovalar
        if (w.any { (it.startsWith("yop") && it.length <= 8) || it.startsWith("tozala") }) {
            return { closeApps(cmd) }
        }
        if (w.any {
                (it.startsWith("och") && !it.startsWith("ochir") && it.length <= 7) ||
                    it == "ishga" || it == "kir" || it == "ishlat"
            }
        ) return { openApp(cmd) }

        if (p("salom", "assalom")) return { speak("Salom! Eshitaman") }
        if (p("rahmat", "raxmat")) return { speak("Arzimaydi") }
        return null
    }

    // ---------- Qo'ng'iroq amallari ----------

    private fun answerCall() {
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            speak("Qo'ng'iroq ruxsati kerak")
            return
        }
        try {
            val tm = getSystemService(TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
            speakerOnLater(900L)
            speakerOnLater(2200L)
            speakerOnLater(4000L)
        } catch (e: Exception) {
            speak("Javob bera olmadim")
        }
    }

    private fun endCall() {
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            speak("Qo'ng'iroq ruxsati kerak")
            return
        }
        try {
            val tm = getSystemService(TELECOM_SERVICE) as TelecomManager
            if (Build.VERSION.SDK_INT >= 28) tm.endCall()
        } catch (e: Exception) {
            speak("Tugata olmadim")
        }
    }

    private fun findContact(cmd: String): Pair<String, String>? {
        val list = ArrayList<Triple<String, String, String>>() // ism, raqam, normallashgan ism
        val cursor = try {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )
        } catch (e: Exception) {
            null
        }
        val cur = cursor ?: return null
        cur.use {
            while (it.moveToNext()) {
                val name = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                val n = normalize(name)
                if (n.length >= 2) list.add(Triple(name, num, n))
            }
        }

        var best: Pair<String, String>? = null
        var bestScore = 0
        for ((name, num, n) in list) {
            val first = n.substringBefore(" ")
            val score = when {
                cmd.contains(n) -> 100 + n.length
                first.length >= 3 && cmd.contains(first) -> first.length
                else -> 0
            }
            if (score > bestScore) {
                best = Pair(name, num)
                bestScore = score
            }
        }
        if (best == null) {
            val skip = listOf("qongiroq", "qil", "telefon", "zvonok", "dinamik", "chaqir")
            val ws = words(cmd).filter { w -> w.length >= 4 && skip.none { w.startsWith(it) } }
            var bestDist = 99
            for ((name, num, n) in list) {
                val first = n.substringBefore(" ")
                if (first.length < 3) continue
                val limit = if (first.length >= 6) 2 else 1
                for (w in ws) {
                    val d = distance(w.take(first.length), first)
                    if (d <= limit && d < bestDist) {
                        best = Pair(name, num)
                        bestDist = d
                    }
                }
            }
        }
        return best
    }

    private fun needOverlay(): Boolean {
        if (Settings.canDrawOverlays(this)) return false
        speak("Boshqa ilovalar ustida ko'rsatish ruxsati kerak")
        return true
    }

    private fun makeCall(cmd: String) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            speak("Qo'ng'iroq qilish ruxsati kerak")
            return
        }
        if (needOverlay()) return

        var number: String? = Regex("\\d{7,}").find(cmd.replace(" ", ""))?.value
        var name: String? = null
        if (number == null) {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                speak("Kontaktlarga kirish ruxsati kerak")
                return
            }
            val found = findContact(cmd)
            if (found == null) {
                speak("Kontakt topilmadi. Men eshitdim: $cmd")
                return
            }
            name = found.first
            number = found.second
        }
        val finalNumber = number ?: return
        val clean = finalNumber.filter { it.isDigit() || it == '+' }
        speak(if (name != null) "$name ga qo'ng'iroq qilaman" else "Qo'ng'iroq qilaman")
        val call = Intent(Intent.ACTION_CALL, Uri.parse("tel:$clean"))
        call.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(call)
            if (hasPrefix(cmd, "dinamik")) {
                speakerOnLater(4000L)
                speakerOnLater(7000L)
            }
        } catch (e: Exception) {
            speak("Qo'ng'iroq qila olmadim")
        }
    }

    private fun readMessages() {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        if (!enabled) {
            speak("Xabarlarga kirish ruxsati yoqilmagan")
            return
        }
        val list = JarvisNotificationListener.takeAll()
        if (list.isEmpty()) {
            speak("Yangi xabar yo'q")
            return
        }
        speak("${list.size} ta xabar. " + list.takeLast(5).joinToString(". "))
    }

    // ---------- Qurilma amallari ----------

    private fun setTorch(on: Boolean) {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                speak("Fonar topilmadi")
                return
            }
            cm.setTorchMode(id, on)
            speak(if (on) "Fonar yoqildi" else "Fonar o'chirildi")
        } catch (e: Exception) {
            speak("Fonarni boshqara olmadim")
        }
    }

    private fun changeVolume(up: Boolean) {
        val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        try {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, 0)
        } catch (e: Exception) {
        }
        speak(if (up) "Ovoz oshirildi" else "Ovoz kamaytirildi")
    }

    private fun mediaKey(code: Int, say: String) {
        try {
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        } catch (e: Exception) {
        }
        speak(say)
    }

    private fun sayTime() {
        val c = Calendar.getInstance()
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        speak(if (m == 0) "Soat $h" else "Soat $h dan $m daqiqa o'tdi")
    }

    private fun sayDate() {
        val c = Calendar.getInstance()
        val d = c.get(Calendar.DAY_OF_MONTH)
        val mo = months[c.get(Calendar.MONTH)]
        val wd = days[c.get(Calendar.DAY_OF_WEEK) - 1]
        speak("Bugun $d $mo, $wd")
    }

    private fun sayBattery() {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        speak("Batareya $p foiz")
    }

    private fun setTimer(cmd: String) {
        var total = 0
        var cur = 0
        for (w in words(cmd)) {
            val n = w.toIntOrNull() ?: numWords[w]
            if (n != null) {
                cur += n
                continue
            }
            when {
                w.startsWith("soniya") || w.startsWith("sekund") -> { total += cur; cur = 0 }
                w.startsWith("daqiqa") || w.startsWith("minut") -> { total += cur * 60; cur = 0 }
                w.startsWith("soat") -> { total += cur * 3600; cur = 0 }
            }
        }
        total += cur * 60
        if (total <= 0) {
            speak("Necha daqiqaga qo'yay?")
            return
        }
        try {
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, total)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            val say = when {
                total >= 3600 && total % 3600 == 0 -> "${total / 3600} soatga"
                total >= 60 -> "${total / 60} daqiqaga"
                else -> "$total soniyaga"
            }
            speak("$say taymer qo'ydim")
        } catch (e: Exception) {
            speak("Taymer qo'ya olmadim")
        }
    }

    private fun nav(action: Int, say: String) {
        val acc = JarvisAccessibility.instance
        if (acc == null) {
            speak("Qulaylik xizmati yoqilmagan")
            return
        }
        acc.doGlobal(action)
        speak(say)
    }

    private fun webSearch(cmd: String) {
        if (needOverlay()) return
        val skip = listOf(
            "google", "gugl", "youtube", "yutub", "yutyub", "internet",
            "brauzer", "chrome", "xrom", "qidir", "izla", "search"
        )
        val q = words(cmd).filter { w -> skip.none { w.startsWith(it) } }.joinToString(" ").trim()
        if (q.isEmpty()) {
            speak("Nimani qidiray?")
            return
        }
        val yt = hasPrefix(cmd, "youtube", "yutub", "yutyub")
        val url = if (yt) {
            "https://www.youtube.com/results?search_query=" + Uri.encode(q)
        } else {
            "https://www.google.com/search?q=" + Uri.encode(q)
        }
        speak(if (yt) "YouTube'da qidiryapman" else "Google'da qidiryapman")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            speak("Ochib bo'lmadi")
        }
    }

    // ---------- Internet funksiyalari ----------

    private fun bg(work: () -> Unit) {
        Thread {
            try {
                work()
            } catch (e: Exception) {
                handler.post { speak("Xatolik yuz berdi") }
            }
        }.start()
    }

    private fun httpGet(url: String, browser: Boolean = false): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            if (browser) {
                c.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0 Safari/537.36"
                )
            }
            if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
        } catch (e: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }

    private fun stripSuffix(w: String): String {
        for (suf in listOf("ning", "dagi", "da", "ni", "ga")) {
            if (w.endsWith(suf) && w.length - suf.length >= 3) return w.substring(0, w.length - suf.length)
        }
        return w
    }

    private fun sayRate(cmd: String) {
        val code = when {
            hasPrefix(cmd, "yevro", "evro") -> "EUR"
            hasPrefix(cmd, "rubl") -> "RUB"
            else -> "USD"
        }
        val name = when (code) {
            "EUR" -> "Yevro"
            "RUB" -> "Rubl"
            else -> "Dollar"
        }
        bg {
            val body = httpGet("https://cbu.uz/uz/arkhiv-kursov-valyut/json/$code/")
            val rate = body?.let { JSONArray(it).getJSONObject(0).getString("Rate").toDouble() }
            handler.post {
                if (rate == null) {
                    speak("Kursni olib bo'lmadi")
                } else {
                    speak("$name kursi ${rate.toInt()} so'm")
                }
            }
        }
    }

    private fun weatherText(c: Int): String = when (c) {
        0 -> "ochiq"
        1, 2 -> "qisman bulutli"
        3 -> "bulutli"
        45, 48 -> "tuman"
        in 51..57 -> "mayda yomg'ir"
        in 61..67 -> "yomg'ir"
        in 71..77 -> "qor"
        in 80..82 -> "jala"
        in 95..99 -> "momaqaldiroq"
        else -> "o'zgaruvchan ob-havo"
    }

    private fun sayWeather(cmd: String) {
        val skipExact = setOf(
            "ob", "bugun", "hozir", "necha", "bilan", "ayt", "aytib", "ber", "bering",
            "qanday", "qancha", "bormi", "qanaqa", "ertaga", "nima"
        )
        val skipPrefix = listOf("havo", "obhavo", "pogoda", "harorat", "gradus")
        val cityRaw = words(cmd).firstOrNull { w ->
            w.length >= 3 && w !in skipExact && skipPrefix.none { w.startsWith(it) }
        }
        val city = cityRaw?.let { stripSuffix(it) }
        bg {
            val lat: Double
            val lon: Double
            val place: String
            if (city != null) {
                val g = httpGet("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + Uri.encode(city))
                val res = g?.let { JSONObject(it).optJSONArray("results") }
                if (res == null || res.length() == 0) {
                    handler.post { speak("Shahar topilmadi") }
                    return@bg
                }
                val r0 = res.getJSONObject(0)
                lat = r0.getDouble("latitude")
                lon = r0.getDouble("longitude")
                place = r0.optString("name", city)
            } else {
                val g = httpGet("https://ipwho.is/")
                val j = g?.let { JSONObject(it) }
                if (j == null || !j.optBoolean("success", false)) {
                    handler.post { speak("Joylashuvni aniqlay olmadim") }
                    return@bg
                }
                lat = j.getDouble("latitude")
                lon = j.getDouble("longitude")
                place = j.optString("city", "")
            }
            val f = httpGet(
                "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                    "&current=temperature_2m,weather_code,wind_speed_10m&timezone=auto"
            )
            val cur = f?.let { JSONObject(it).getJSONObject("current") }
            if (cur == null) {
                handler.post { speak("Ob-havoni olib bo'lmadi") }
                return@bg
            }
            val t = Math.round(cur.getDouble("temperature_2m")).toInt()
            val wind = Math.round(cur.getDouble("wind_speed_10m")).toInt()
            val desc = weatherText(cur.getInt("weather_code"))
            val where = if (place.isNotEmpty()) "$place da" else "Hozir"
            handler.post { speak("$where harorat $t daraja, $desc. Shamol soatiga $wind kilometr") }
        }
    }

    private fun playSong(cmd: String) {
        if (needOverlay()) return
        val skipPrefix = listOf("youtube", "yutub", "yutyub", "qoshiq", "qoshig", "musiqa", "klip", "kuy", "ijro")
        val skipExact = setOf("qoy", "qoyib", "qoying", "chal", "chalib", "chaling")
        val q = words(cmd)
            .filter { w -> w !in skipExact && skipPrefix.none { w.startsWith(it) } }
            .joinToString(" ") { stripSuffix(it) }
            .trim()
        if (q.isEmpty()) {
            speak("Qaysi qo'shiqni qo'yay?")
            return
        }
        speak("$q ni qidiryapman")
        bg {
            val html = httpGet("https://www.youtube.com/results?search_query=" + Uri.encode(q), true)
            val id = html?.let {
                Regex("\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(it)?.groupValues?.get(1)
            }
            val url = if (id != null) {
                "https://www.youtube.com/watch?v=$id"
            } else {
                "https://www.youtube.com/results?search_query=" + Uri.encode(q)
            }
            handler.post {
                val view = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    view.setPackage("com.google.android.youtube")
                    startActivity(view)
                } catch (e: Exception) {
                    try {
                        view.setPackage(null)
                        startActivity(view)
                    } catch (e2: Exception) {
                        speak("Ochib bo'lmadi")
                    }
                }
            }
        }
    }

    private fun askAi(q: String, key: String) {
        speak("Bir lahza")
        bg {
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            val body = JSONObject()
            body.put("model", "claude-haiku-5-5")
            body.put("max_tokens", 300)
            body.put(
                "system",
                "Sen Jarvis ismli ovozli yordamchisan. O'zbek tilida, juda qisqa (ko'pi bilan 2-3 gap), " +
                    "oddiy matnda, hech qanday belgi va ro'yxatsiz javob ber."
            )
            val msgs = JSONArray()
            msgs.put(JSONObject().put("role", "user").put("content", q))
            body.put("messages", msgs)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = if (code in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
            c.disconnect()
            val answer = text?.let {
                JSONObject(it).getJSONArray("content").getJSONObject(0).getString("text")
            }
            handler.post {
                when {
                    code == 401 -> speak("AI kaliti noto'g'ri")
                    answer == null -> speak("AI javob bermadi")
                    else -> speak(answer)
                }
            }
        }
    }

    // ---------- SMS, budilnik, kamera, ovoz ----------

    private fun ask(h: (List<String>) -> Unit) {
        pendingHandler = h
        pendingUntil = SystemClock.elapsedRealtime() + 25000L
    }

    private fun isYes(alts: List<String>): Boolean {
        val yes = setOf("ha", "xa", "yubor", "yuboring", "mayli", "albatta", "xop", "hop", "ok", "okey", "tasdiqlayman")
        return alts.any { a -> words(a).any { it in yes } }
    }

    private fun composeSms(cmd: String) {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            speak("SMS yuborish ruxsati kerak")
            return
        }
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            speak("Kontaktlarga kirish ruxsati kerak")
            return
        }
        val ws = words(cmd)
        val idx = ws.indexOfFirst { it.startsWith("yoz") || it.startsWith("yubor") || it.startsWith("jonat") }
        val before = if (idx >= 0) ws.take(idx).joinToString(" ") else cmd
        val text = if (idx >= 0) ws.drop(idx + 1).joinToString(" ") else ""
        val found = findContact(before) ?: findContact(cmd)
        if (found == null) {
            speak("Kontakt topilmadi. Men eshitdim: $cmd")
            return
        }
        val name = found.first
        val number = found.second
        if (text.isBlank()) {
            speak("$name ga nima deb yozay?")
            ask { alts -> confirmSms(name, number, alts.firstOrNull() ?: "") }
        } else {
            confirmSms(name, number, text)
        }
    }

    private fun confirmSms(name: String, number: String, text: String) {
        if (text.isBlank()) {
            speak("Xabar bo'sh, bekor qilindi")
            return
        }
        speak("$name ga yuboraymi: $text. Ha yoki yo'q deng")
        ask { alts ->
            if (isYes(alts)) sendSms(number, text) else speak("Bekor qilindi")
        }
    }

    private fun sendSms(number: String, text: String) {
        try {
            val sms = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(SmsManager::class.java)
            } else {
                SmsManager.getDefault()
            }
            val clean = number.filter { it.isDigit() || it == '+' }
            sms.sendMultipartTextMessage(clean, null, sms.divideMessage(text), null, null)
            speak("Yuborildi")
        } catch (e: Exception) {
            speak("Yubora olmadim")
        }
    }

    private fun setAlarm(cmd: String) {
        val nums = ArrayList<Int>()
        var half = false
        for (w in words(cmd)) {
            if (w.startsWith("yarim")) {
                half = true
                continue
            }
            val n = w.toIntOrNull() ?: numWords[w]
            if (n != null) nums.add(n)
        }
        if (nums.isEmpty()) {
            speak("Soat nechiga qo'yay?")
            return
        }
        var hour = nums[0]
        val minute = if (half) 30 else nums.drop(1).sum()
        if (hasPrefix(cmd, "kech", "tush", "oqshom") && hour < 12) hour += 12
        if (hour > 23 || minute > 59) {
            speak("Vaqtni tushunmadim")
            return
        }
        try {
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            speak(if (minute == 0) "Budilnik soat $hour ga qo'yildi" else "Budilnik soat $hour $minute ga qo'yildi")
        } catch (e: Exception) {
            speak("Budilnik qo'ya olmadim")
        }
    }

    private fun takePhoto(cmd: String) {
        if (needOverlay()) return
        val acc = JarvisAccessibility.instance
        if (acc == null) {
            speak("Qulaylik xizmati yoqilmagan")
            return
        }
        val i = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (hasPrefix(cmd, "selfi")) i.putExtra("android.intent.extras.CAMERA_FACING", 1)
        try {
            startActivity(i)
        } catch (e: Exception) {
            speak("Kamerani ochib bo'lmadi")
            return
        }
        speak("Uch soniyadan keyin suratga olaman")
        handler.postDelayed({
            val ok = acc.clickAny(
                listOf(
                    "take picture", "shutter", "сделать снимок", "сфотографировать",
                    "снимок", "съемка", "снять", "фото", "photo"
                )
            )
            if (ok) speak("Suratga oldim")
        }, 4500L)
    }

    private fun voicesForCurrent(t: TextToSpeech): List<Voice> {
        val lang = t.voice?.locale?.language ?: return emptyList()
        return try {
            (t.voices ?: emptySet<Voice>()).filter { it.locale.language == lang }.sortedBy { it.name }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun applySavedVoice(t: TextToSpeech) {
        val saved = getSharedPreferences("jarvis", MODE_PRIVATE).getString("voice", null) ?: return
        try {
            val v = (t.voices ?: emptySet<Voice>()).firstOrNull { it.name == saved }
            if (v != null) t.voice = v
        } catch (e: Exception) {
        }
    }

    private fun nextVoice() {
        val t = tts ?: return
        val list = voicesForCurrent(t)
        if (list.size < 2) {
            speak("Boshqa ovoz yo'q")
            return
        }
        val cur = t.voice?.name
        val idx = list.indexOfFirst { it.name == cur }
        val next = list[(idx + 1) % list.size]
        try {
            t.voice = next
        } catch (e: Exception) {
        }
        getSharedPreferences("jarvis", MODE_PRIVATE).edit().putString("voice", next.name).apply()
        speak("Men Jarvisman. Bu mening yangi ovozim")
    }

    // ---------- Ilovalarni ochish va yopish ----------

    private fun homePackage(): String? {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
    }

    private fun closeApps(cmd: String) {
        val acc = JarvisAccessibility.instance
        if (acc == null) {
            speak("Qulaylik xizmati yoqilmagan")
            return
        }
        if (hasPrefix(cmd, "hamma", "barcha")) {
            speak("Hammasini yopaman")
            acc.closeAllApps()
            return
        }
        val found = findApp(cmd, false)
        val target = found?.activityInfo?.packageName ?: acc.foregroundPackage()
        if (target == null || target == packageName || target == homePackage()) {
            speak("Hammasini yopaman")
            acc.closeAllApps()
            return
        }
        val label = found?.loadLabel(packageManager)?.toString()
        speak(if (label != null) "$label yopilmoqda" else "Yopaman")
        acc.goHomeThen {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            am.killBackgroundProcesses(target)
        }
    }

    private fun labelOf(ri: ResolveInfo): String =
        normalize(ri.loadLabel(packageManager).toString())

    private fun findApp(cmd: String, fuzzy: Boolean = true): ResolveInfo? {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }

        var best: ResolveInfo? = null
        var bestScore = 0
        for (ri in apps) {
            val label = labelOf(ri)
            if (label.length < 2) continue
            val first = label.substringBefore(" ")
            val score = when {
                cmd.contains(label) -> 100 + label.length
                first.length >= 3 && cmd.contains(first) -> first.length
                else -> 0
            }
            if (score > bestScore) {
                best = ri
                bestScore = score
            }
        }

        if (best == null) {
            for ((key, targets) in aliases) {
                if (words(cmd).any { it.startsWith(key) }) {
                    best = apps.firstOrNull { ri ->
                        val l = labelOf(ri)
                        targets.any { l.contains(it) }
                    }
                    if (best != null) break
                }
            }
        }

        if (best == null && fuzzy) {
            val ws = words(cmd).filter { it.length >= 4 }
            var bestDist = 99
            for (ri in apps) {
                val f = labelOf(ri).substringBefore(" ")
                if (f.length < 4) continue
                val limit = if (f.length >= 7) 2 else 1
                for (w in ws) {
                    val d = distance(w.take(f.length), f)
                    if (d <= limit && d < bestDist) {
                        best = ri
                        bestDist = d
                    }
                }
            }
        }
        return best
    }

    private fun openApp(cmd: String) {
        if (needOverlay()) return
        val target = findApp(cmd)
        if (target == null) {
            speak("Bunday ilova topilmadi. Men eshitdim: $cmd")
            return
        }
        val label = target.loadLabel(packageManager).toString()
        val launch = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(target.activityInfo.packageName, target.activityInfo.name))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(launch)
            speak("$label ochilmoqda")
        } catch (e: Exception) {
            speak("Ochib bo'lmadi")
        }
    }
}
