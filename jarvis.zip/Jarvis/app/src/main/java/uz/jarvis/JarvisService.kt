package uz.jarvis

import android.Manifest
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.TelecomManager
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var running = false
    private var speaking = false
    private var awaitingCommand = false
    private var awaitingUntil = 0L

    private val listenRunnable = Runnable { startListening() }

    // "Jarvis" so'zining turli eshitilish variantlari
    private val wakeWords = listOf(
        "jarvis", "djarvis", "jarvas", "jarvic", "jarviz",
        "yarvis", "jervis", "zharvis", "charvis", "garvis"
    )

    private val cyr = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e",
        'ё' to "yo", 'ж' to "j", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k",
        'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r",
        'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "x", 'ц' to "ts",
        'ч' to "ch", 'ш' to "sh", 'щ' to "sh", 'ъ' to "", 'ы' to "i", 'ь' to "",
        'э' to "e", 'ю' to "yu", 'я' to "ya", 'ў' to "o", 'қ' to "q", 'ғ' to "g",
        'ҳ' to "h"
    )

    // Aytilgan so'z -> ilova nomida qidiriladigan so'zlar
    private val aliases = mapOf(
        "yutub" to listOf("youtube"),
        "yutyub" to listOf("youtube"),
        "vatsap" to listOf("whatsapp"),
        "watsap" to listOf("whatsapp"),
        "uotsap" to listOf("whatsapp"),
        "sozlama" to listOf("settings", "nastroyki", "sozlamalar"),
        "kamera" to listOf("camera", "kamera"),
        "galer" to listOf("gallery", "galereya"),
        "galir" to listOf("gallery", "galereya"),
        "xrom" to listOf("chrome"),
        "hrom" to listOf("chrome"),
        "brauzer" to listOf("chrome", "internet", "browser"),
        "kalkulyator" to listOf("calculator", "kalkulyator"),
        "kalkulator" to listOf("calculator", "kalkulyator"),
        "telefon" to listOf("phone", "telefon"),
        "kontakt" to listOf("contacts", "kontakty", "kontakt"),
        "soat" to listOf("clock", "chasy"),
        "musiqa" to listOf("music", "muzyka"),
        "xarita" to listOf("maps", "karty")
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        running = true
        scheduleListen(500L)
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis ishlayapti")
            .setContentText("\"Jarvis\" deb buyruq bering")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    // ---------- Ovoz chiqarish (TTS) ----------

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        var r = t.setLanguage(Locale("uz", "UZ"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = t.setLanguage(Locale("ru", "RU"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                t.setLanguage(Locale.getDefault())
            }
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                handler.post { speaking = false; scheduleListen(200L) }
            }
            override fun onError(utteranceId: String?) {
                handler.post { speaking = false; scheduleListen(200L) }
            }
        })
        ttsReady = true
    }

    private fun speak(text: String) {
        val t = tts
        if (!ttsReady || t == null) return
        speaking = true
        recognizer?.cancel()
        val r = t.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, Bundle(), "j" + System.currentTimeMillis())
        if (r != TextToSpeech.SUCCESS) speaking = false
    }

    // ---------- Eshitish ----------

    private fun scheduleListen(delay: Long) {
        handler.removeCallbacks(listenRunnable)
        handler.postDelayed(listenRunnable, delay)
    }

    private fun startListening() {
        if (!running) return
        if (speaking) {
            scheduleListen(500L)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(listener)
        recognizer = r

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "uz-UZ")
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        r.startListening(intent)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                stopSelf()
                return
            }
            scheduleListen(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 300L)
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            handleHeard(list ?: emptyList())
        }
    }

    // ---------- Buyruqlarni tushunish ----------

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase(Locale.ROOT)) {
            when (ch) {
                '\'', '’', 'ʻ', 'ʼ', '`', '‘' -> {}
                else -> sb.append(cyr[ch] ?: ch.toString())
            }
        }
        return sb.toString()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun words(s: String): List<String> = s.split(" ").filter { it.isNotEmpty() }

    private fun hasPrefix(cmd: String, vararg prefixes: String): Boolean =
        words(cmd).any { w -> prefixes.any { p -> w.startsWith(p) } }

    private fun hasExact(cmd: String, vararg exact: String): Boolean =
        words(cmd).any { w -> w in exact }

    private fun handleHeard(heard: List<String>) {
        val alts = heard.map { normalize(it) }.filter { it.isNotEmpty() }
        if (alts.isEmpty()) {
            scheduleListen(300L)
            return
        }
        val now = SystemClock.elapsedRealtime()

        if (awaitingCommand && now < awaitingUntil) {
            awaitingCommand = false
            execute(alts[0])
            scheduleListen(400L)
            return
        }
        awaitingCommand = false

        for (t in alts) {
            for (w in wakeWords) {
                val i = t.indexOf(w)
                if (i >= 0) {
                    val rest = t.substring(i + w.length).trim()
                    if (rest.isEmpty()) {
                        awaitingCommand = true
                        awaitingUntil = now + 10000L
                        speak("Eshitaman")
                    } else {
                        execute(rest)
                    }
                    scheduleListen(400L)
                    return
                }
            }
        }
        scheduleListen(300L)
    }

    private fun execute(cmd: String) {
        when {
            hasPrefix(cmd, "javob", "trubka", "qabul", "kotar") -> answerCall()
            hasPrefix(cmd, "xabar", "habar", "sms", "yozishma") -> readMessages()
            hasExact(cmd, "yop", "yoping", "yopib", "yopgin", "tozala", "tozalab") -> closeApps(cmd)
            hasExact(cmd, "och", "oching", "ochib", "ochgin", "ishga") -> openApp(cmd)
            else -> speak("Tushunmadim")
        }
    }

    // ---------- Amallar ----------

    private fun answerCall() {
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
            speak("Qo'ng'iroq ruxsati kerak")
            return
        }
        try {
            val tm = getSystemService(TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
        } catch (e: Exception) {
            speak("Javob bera olmadim")
        }
    }

    private fun readMessages() {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        if (!enabled) {
            speak("Xabarlarga kirish ruxsati yoqilmagan")
            return
        }
        val list = JarvisNotificationListener.takeAll()
        if (list.isEmpty()) {
            speak("Yangi xabar yo'q")
            return
        }
        speak("${list.size} ta xabar. " + list.takeLast(5).joinToString(". "))
    }

    private fun homePackage(): String? {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
    }

    private fun closeApps(cmd: String) {
        val acc = JarvisAccessibility.instance
        if (acc == null) {
            speak("Qulaylik xizmati yoqilmagan")
            return
        }
        if (hasPrefix(cmd, "hamma", "barcha")) {
            speak("Hammasini yopaman")
            acc.closeAllApps()
            return
        }
        val target = findApp(cmd, false)?.activityInfo?.packageName ?: acc.foregroundPackage()
        if (target == null || target == packageName || target == homePackage()) {
            speak("Hammasini yopaman")
            acc.closeAllApps()
            return
        }
        speak("Yopaman")
        acc.goHomeThen {
            val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            am.killBackgroundProcesses(target)
        }
    }

    private fun distance(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
            }
        }
        return dp[a.length][b.length]
    }

    private fun labelOf(ri: ResolveInfo): String =
        normalize(ri.loadLabel(packageManager).toString())

    private fun findApp(cmd: String, fuzzy: Boolean = true): ResolveInfo? {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }

        var best: ResolveInfo? = null
        var bestScore = 0
        for (ri in apps) {
            val label = labelOf(ri)
            if (label.length < 2) continue
            val first = label.substringBefore(" ")
            val score = when {
                cmd.contains(label) -> 100 + label.length
                first.length >= 3 && cmd.contains(first) -> first.length
                else -> 0
            }
            if (score > bestScore) {
                best = ri
                bestScore = score
            }
        }

        if (best == null) {
            for ((key, targets) in aliases) {
                if (words(cmd).any { it.startsWith(key) }) {
                    best = apps.firstOrNull { ri ->
                        val l = labelOf(ri)
                        targets.any { l.contains(it) }
                    }
                    if (best != null) break
                }
            }
        }

        // Noaniq eshitilgan nomlar uchun: o'xshash so'zni qidirish
        if (best == null && fuzzy) {
            val ws = words(cmd).filter { it.length >= 4 }
            var bestDist = 99
            for (ri in apps) {
                val f = labelOf(ri).substringBefore(" ")
                if (f.length < 4) continue
                val limit = if (f.length >= 7) 2 else 1
                for (w in ws) {
                    val d = distance(w.take(f.length), f)
                    if (d <= limit && d < bestDist) {
                        best = ri
                        bestDist = d
                    }
                }
            }
        }
        return best
    }

    private fun openApp(cmd: String) {
        if (!Settings.canDrawOverlays(this)) {
            speak("Boshqa ilovalar ustida ko'rsatish ruxsati kerak")
            return
        }
        val target = findApp(cmd)
        if (target == null) {
            speak("Bunday ilova topilmadi. Men eshitdim: $cmd")
            return
        }
        val launch = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(target.activityInfo.packageName, target.activityInfo.name))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(launch)
        } catch (e: Exception) {
            speak("Ochib bo'lmadi")
        }
    }
}
