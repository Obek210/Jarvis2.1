package uz.jarvis

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibility : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibility? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    private val closeTexts = listOf(
        "close all", "clear all", "закрыть все", "закрыть всё",
        "очистить все", "barchasini yopish", "hammasini yopish"
    )

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Oxirgi ilovalar oynasini ochib, "Hammasini yopish" tugmasini bosadi. */
    fun closeAllApps(attempt: Int = 0) {
        if (attempt == 0) performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed({
            val root = rootInActiveWindow
            val clicked = root != null && clickCloseAll(root)
            if (clicked) {
                handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 600)
            } else if (attempt < 3) {
                closeAllApps(attempt + 1)
            } else {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
        }, 900)
    }

    private fun clickCloseAll(root: AccessibilityNodeInfo): Boolean {
        for (t in closeTexts) {
            val nodes = root.findAccessibilityNodeInfosByText(t) ?: continue
            for (n in nodes) {
                var cur: AccessibilityNodeInfo? = n
                while (cur != null) {
                    if (cur.isClickable) {
                        cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        return true
                    }
                    cur = cur.parent
                }
            }
        }
        return false
    }
}
