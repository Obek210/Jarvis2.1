package uz.jarvis

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibility : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibility? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lastPackage: String? = null

    private val closeTexts = listOf(
        "close all", "clear all", "закрыть все", "закрыть всё",
        "очистить все", "barchasini yopish", "hammasini yopish"
    )

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg != "com.android.systemui" && pkg != packageName) lastPackage = pkg
    }

    override fun onInterrupt() {}

    /** Hozir ekranda turgan ilovaning paketi. */
    fun foregroundPackage(): String? {
        val p = rootInActiveWindow?.packageName?.toString()
        return if (p != null && p != "com.android.systemui" && p != packageName) p else lastPackage
    }

    fun doGlobal(action: Int) {
        performGlobalAction(action)
    }

    /** Bosh ekranga chiqib, biroz kutib, amalni bajaradi. */
    fun goHomeThen(action: () -> Unit) {
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({ action() }, 900)
    }

    /** Oxirgi ilovalar oynasini ochib, "Hammasini yopish" tugmasini bosadi. */
    fun closeAllApps(attempt: Int = 0) {
        if (attempt == 0) performGlobalAction(GLOBAL_ACTION_RECENTS)
        handler.postDelayed({
            if (findAndClick()) {
                handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 600)
            } else if (attempt < 3) {
                closeAllApps(attempt + 1)
            } else {
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
        }, 1000)
    }

    private fun findAndClick(): Boolean {
        val roots = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { roots.add(it) }
        try {
            for (w in windows) {
                w.root?.let { roots.add(it) }
            }
        } catch (e: Exception) {
        }
        for (r in roots) {
            if (clickCloseAll(r)) return true
        }
        return false
    }

    private fun clickCloseAll(root: AccessibilityNodeInfo): Boolean {
        for (t in closeTexts) {
            val nodes = root.findAccessibilityNodeInfosByText(t) ?: continue
            for (n in nodes) {
                var cur: AccessibilityNodeInfo? = n
                while (cur != null) {
                    if (cur.isClickable) {
                        cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        return true
                    }
                    cur = cur.parent
                }
            }
        }
        return false
    }
}
